import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

public class RandomWord {
    public static void main(String[] args) {
        String champion = null;
        int count = 0;

        while (!StdIn.isEmpty()) {
            String currentWord = StdIn.readString();
            count++;

            // Select the current word with probability 1/count
            if (StdRandom.uniformInt(count) == 0) {
                champion = currentWord;
            }
        }

        if (champion != null) {
            StdOut.println(champion);
        }
    }
}


// import java.util.Scanner;
// import java.util.Random;

// public class RandomWord {
//     public static void main(String[] args) {
//         Scanner scanner = new Scanner(System.in);
//         Random random = new Random();

//         String champion = null;
//         int count = 0;

//         while (scanner.hasNext()) {
//             String currentWord = scanner.next();
//             count++;

//             // Select the current word with probability 1/count
//             if (random.nextInt(count) == 0) {
//                 champion = currentWord;
//             }
//         }

//         scanner.close();

//         if (champion != null) {
//             System.out.println(champion);
//         }
//     }
// }
