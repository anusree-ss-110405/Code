import edu.princeton.cs.algs4.StdOut;

public class HelloWorld {
    public static void main(String[] args) {
        // Prints "Hello, World" in the terminal window using StdOut.
        StdOut.println("Hello, World");
    }
}
// package src;
// public class HelloWorld {
//     public static void main(String[] args) {
//        // Prints "Hello, World" in the terminal window.
//        System.out.println("Hello, World");
//     }
//  }